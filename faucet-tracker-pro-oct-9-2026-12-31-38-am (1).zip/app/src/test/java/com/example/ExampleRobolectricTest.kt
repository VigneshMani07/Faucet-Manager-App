package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.FaucetItem
import com.example.data.FaucetStatus
import com.example.data.InitialFaucetData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Faucet List", appName)
    }

    @Test
    fun `default faucet presets contain expected items`() {
        val presets = InitialFaucetData.defaultFaucets
        assertTrue("Presets should not be empty", presets.isNotEmpty())
        val freeBitcoin = presets.firstOrNull { it.name.contains("FreeBitco", ignoreCase = true) }
        assertTrue("FreeBitco.in preset should exist", freeBitcoin != null)
        assertEquals(FaucetStatus.PAYING, freeBitcoin?.status)
    }
}
