package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [FaucetItem::class], version = 1, exportSchema = false)
@TypeConverters(FaucetTypeConverters::class)
abstract class FaucetDatabase : RoomDatabase() {
    abstract fun faucetDao(): FaucetDao

    companion object {
        @Volatile
        private var INSTANCE: FaucetDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): FaucetDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FaucetDatabase::class.java,
                    "faucets_database"
                )
                    .addCallback(FaucetDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class FaucetDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.faucetDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: FaucetDao) {
            if (dao.getCount() == 0) {
                dao.insertAll(InitialFaucetData.defaultFaucets)
            }
        }
    }
}
