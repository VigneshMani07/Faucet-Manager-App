package com.example.data

import kotlinx.coroutines.flow.Flow

class FaucetRepository(private val dao: FaucetDao) {
    val allFaucets: Flow<List<FaucetItem>> = dao.getAllFaucets()

    fun getFaucetById(id: Long): Flow<FaucetItem?> = dao.getFaucetById(id)

    suspend fun insertFaucet(faucet: FaucetItem): Long = dao.insertFaucet(faucet)

    suspend fun updateFaucet(faucet: FaucetItem) = dao.updateFaucet(faucet)

    suspend fun deleteFaucet(faucet: FaucetItem) = dao.deleteFaucet(faucet)

    suspend fun deleteFaucetById(id: Long) = dao.deleteFaucetById(id)

    suspend fun setCompletion(id: Long, isCompleted: Boolean, date: String) =
        dao.updateCompletion(id, isCompleted, date)

    suspend fun resetAllDailyCompleted() = dao.resetAllCompleted()

    suspend fun markAllDailyCompleted(date: String) = dao.markAllCompleted(date)

    suspend fun toggleFavorite(id: Long, isFavorite: Boolean) = dao.setFavorite(id, isFavorite)

    suspend fun startTimer(id: Long, durationMinutes: Int) {
        dao.updateTimer(id, System.currentTimeMillis(), durationMinutes)
    }

    suspend fun clearTimer(id: Long) {
        dao.updateTimer(id, 0L, 0)
    }

    suspend fun restoreDefaultPresets() {
        dao.insertAll(InitialFaucetData.defaultFaucets)
    }

    suspend fun clearAll() {
        dao.deleteAll()
    }

    suspend fun importFaucets(faucets: List<FaucetItem>) {
        dao.insertAll(faucets)
    }

    suspend fun getCount(): Int = dao.getCount()
}
