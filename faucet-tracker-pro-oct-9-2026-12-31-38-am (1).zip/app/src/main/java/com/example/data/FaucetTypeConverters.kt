package com.example.data

import androidx.room.TypeConverter

class FaucetTypeConverters {
    @TypeConverter
    fun fromFaucetStatus(status: FaucetStatus?): String {
        return status?.name ?: FaucetStatus.ACTIVE.name
    }

    @TypeConverter
    fun toFaucetStatus(value: String?): FaucetStatus {
        return if (value != null) FaucetStatus.fromString(value) else FaucetStatus.ACTIVE
    }
}
