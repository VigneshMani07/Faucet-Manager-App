package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.StatusActive
import com.example.ui.theme.StatusDegraded
import com.example.ui.theme.StatusInactive
import com.example.ui.theme.StatusPaying
import com.example.ui.theme.StatusScam
import com.example.ui.theme.StatusTesting

enum class FaucetStatus(val displayName: String, val badgeColor: Color) {
    PAYING("Paying", StatusPaying),
    ACTIVE("Active", StatusActive),
    TESTING("Testing", StatusTesting),
    DEGRADED("Slow / Issues", StatusDegraded),
    INACTIVE("Inactive", StatusInactive),
    SCAM("Scam / Caution", StatusScam);

    companion object {
        fun fromString(value: String): FaucetStatus {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: ACTIVE
        }
    }
}
