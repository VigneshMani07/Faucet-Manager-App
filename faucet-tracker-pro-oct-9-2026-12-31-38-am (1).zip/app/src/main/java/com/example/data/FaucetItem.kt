package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "faucets")
data class FaucetItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val url: String,
    val expectedDailyReward: String,
    val estimatedDailyUsd: Double = 0.0,
    val estimatedTimeMinutes: Int = 10,
    val status: FaucetStatus = FaucetStatus.ACTIVE,
    val claimInterval: String = "Hourly",
    val paymentMethod: String = "FaucetPay",
    val supportedCoins: String = "BTC, USDT",
    val minimumWithdrawal: String = "Low",
    val notes: String = "",
    val isCompletedToday: Boolean = false,
    val lastCompletedDate: String = "",
    val isFavorite: Boolean = false,
    val rating: Int = 4,
    val timerDurationMinutes: Int = 60,
    val timerStartedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)
