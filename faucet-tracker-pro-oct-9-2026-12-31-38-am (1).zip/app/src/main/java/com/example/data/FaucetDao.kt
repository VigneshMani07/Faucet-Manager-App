package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface FaucetDao {
    @Query("SELECT * FROM faucets ORDER BY isFavorite DESC, id ASC")
    fun getAllFaucets(): Flow<List<FaucetItem>>

    @Query("SELECT * FROM faucets WHERE id = :id LIMIT 1")
    fun getFaucetById(id: Long): Flow<FaucetItem?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFaucet(faucet: FaucetItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(faucets: List<FaucetItem>)

    @Update
    suspend fun updateFaucet(faucet: FaucetItem)

    @Delete
    suspend fun deleteFaucet(faucet: FaucetItem)

    @Query("DELETE FROM faucets WHERE id = :id")
    suspend fun deleteFaucetById(id: Long)

    @Query("DELETE FROM faucets")
    suspend fun deleteAll()

    @Query("UPDATE faucets SET isCompletedToday = :completed, lastCompletedDate = :date WHERE id = :id")
    suspend fun updateCompletion(id: Long, completed: Boolean, date: String)

    @Query("UPDATE faucets SET isCompletedToday = 0")
    suspend fun resetAllCompleted()

    @Query("UPDATE faucets SET isCompletedToday = 1, lastCompletedDate = :date")
    suspend fun markAllCompleted(date: String)

    @Query("UPDATE faucets SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun setFavorite(id: Long, isFavorite: Boolean)

    @Query("UPDATE faucets SET timerStartedAt = :startedAt, timerDurationMinutes = :duration WHERE id = :id")
    suspend fun updateTimer(id: Long, startedAt: Long, duration: Int)

    @Query("SELECT COUNT(*) FROM faucets")
    suspend fun getCount(): Int
}
