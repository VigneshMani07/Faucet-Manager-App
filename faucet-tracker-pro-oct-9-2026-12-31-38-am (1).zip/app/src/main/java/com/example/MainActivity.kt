package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.FaucetListScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.FaucetViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: FaucetViewModel = viewModel()
                FaucetListScreen(viewModel = viewModel)
            }
        }
    }
}
