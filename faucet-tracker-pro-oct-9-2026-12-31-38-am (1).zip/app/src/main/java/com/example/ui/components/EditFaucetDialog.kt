package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FaucetItem
import com.example.data.FaucetStatus
import com.example.ui.theme.AmberPrimary

@Composable
fun EditFaucetDialog(
    initialFaucet: FaucetItem?,
    onDismiss: () -> Unit,
    onSave: (FaucetItem) -> Unit
) {
    val isEditing = initialFaucet != null

    var name by remember { mutableStateOf(initialFaucet?.name ?: "") }
    var url by remember { mutableStateOf(initialFaucet?.url ?: "") }
    var expectedDailyReward by remember { mutableStateOf(initialFaucet?.expectedDailyReward ?: "~$0.30") }
    var estimatedDailyUsdText by remember { mutableStateOf(initialFaucet?.estimatedDailyUsd?.toString() ?: "0.30") }
    var estimatedTimeMinutes by remember { mutableFloatStateOf(initialFaucet?.estimatedTimeMinutes?.toFloat() ?: 10f) }
    var status by remember { mutableStateOf(initialFaucet?.status ?: FaucetStatus.ACTIVE) }
    var claimInterval by remember { mutableStateOf(initialFaucet?.claimInterval ?: "Every 60 min") }
    var paymentMethod by remember { mutableStateOf(initialFaucet?.paymentMethod ?: "FaucetPay") }
    var supportedCoins by remember { mutableStateOf(initialFaucet?.supportedCoins ?: "BTC, USDT") }
    var minimumWithdrawal by remember { mutableStateOf(initialFaucet?.minimumWithdrawal ?: "Low") }
    var notes by remember { mutableStateOf(initialFaucet?.notes ?: "") }
    var isFavorite by remember { mutableStateOf(initialFaucet?.isFavorite ?: false) }
    var rating by remember { mutableIntStateOf(initialFaucet?.rating ?: 4) }
    var timerDurationText by remember { mutableStateOf(initialFaucet?.timerDurationMinutes?.toString() ?: "60") }

    var statusDropdownExpanded by remember { mutableStateOf(false) }
    var intervalDropdownExpanded by remember { mutableStateOf(false) }
    var paymentDropdownExpanded by remember { mutableStateOf(false) }

    var nameError by remember { mutableStateOf(false) }
    var urlError by remember { mutableStateOf(false) }

    val intervalPresets = listOf("Every 5 min", "Every 15 min", "Every 30 min", "Every 60 min", "Daily (24h)", "Continuous / PTC")
    val paymentPresets = listOf("FaucetPay", "Direct Crypto Wallet", "Cwallet", "Payeer", "Binance", "Web3 Wallet")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEditing) "Edit Faucet" else "Add New Faucet",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Name Field (Required)
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        nameError = false
                    },
                    label = { Text("Faucet Name *") },
                    placeholder = { Text("e.g. FreeBitco.in or FireFaucet") },
                    isError = nameError,
                    supportingText = { if (nameError) Text("Name cannot be empty") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_input_name")
                )

                // Website Link (Required)
                OutlinedTextField(
                    value = url,
                    onValueChange = {
                        url = it
                        urlError = false
                    },
                    label = { Text("Website Link / URL *") },
                    placeholder = { Text("https://example.com") },
                    isError = urlError,
                    supportingText = { if (urlError) Text("URL cannot be empty") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_input_url")
                )

                // Status Dropdown
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = status.displayName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Website Status") },
                        trailingIcon = {
                            Icon(Icons.Default.ArrowDropDown, "Select status")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { statusDropdownExpanded = true }
                            .testTag("dialog_input_status")
                    )

                    DropdownMenu(
                        expanded = statusDropdownExpanded,
                        onDismissRequest = { statusDropdownExpanded = false }
                    ) {
                        FaucetStatus.entries.forEach { s ->
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(s.displayName, color = s.badgeColor, fontWeight = FontWeight.Bold)
                                    }
                                },
                                onClick = {
                                    status = s
                                    statusDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Expected Daily Reward (Display text)
                OutlinedTextField(
                    value = expectedDailyReward,
                    onValueChange = { expectedDailyReward = it },
                    label = { Text("Expected Daily Reward (Display)") },
                    placeholder = { Text("e.g. ~$0.50 or 250 Satoshis") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_input_reward_text")
                )

                // Estimated Daily USD (Numeric for calculations)
                OutlinedTextField(
                    value = estimatedDailyUsdText,
                    onValueChange = { estimatedDailyUsdText = it },
                    label = { Text("Estimated Daily USD ($)") },
                    placeholder = { Text("0.50") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    supportingText = { Text("Used to compute total daily & monthly portfolio earnings") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_input_reward_usd")
                )

                // Estimated Daily Task Time (Minutes Slider)
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Estimated Daily Task Time:",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${estimatedTimeMinutes.toInt()} minutes",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = AmberPrimary
                        )
                    }
                    Slider(
                        value = estimatedTimeMinutes,
                        onValueChange = { estimatedTimeMinutes = it },
                        valueRange = 1f..120f,
                        steps = 23,
                        modifier = Modifier.testTag("dialog_slider_time")
                    )
                }

                // Claim Interval Dropdown with presets
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = claimInterval,
                        onValueChange = { claimInterval = it },
                        label = { Text("Claim Interval / Frequency") },
                        trailingIcon = {
                            IconButton(onClick = { intervalDropdownExpanded = true }) {
                                Icon(Icons.Default.ArrowDropDown, "Presets")
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_input_interval")
                    )

                    DropdownMenu(
                        expanded = intervalDropdownExpanded,
                        onDismissRequest = { intervalDropdownExpanded = false }
                    ) {
                        intervalPresets.forEach { preset ->
                            DropdownMenuItem(
                                text = { Text(preset) },
                                onClick = {
                                    claimInterval = preset
                                    intervalDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Payment Method with presets
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = paymentMethod,
                        onValueChange = { paymentMethod = it },
                        label = { Text("Payment Method / Microwallet") },
                        trailingIcon = {
                            IconButton(onClick = { paymentDropdownExpanded = true }) {
                                Icon(Icons.Default.ArrowDropDown, "Presets")
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dialog_input_payment")
                    )

                    DropdownMenu(
                        expanded = paymentDropdownExpanded,
                        onDismissRequest = { paymentDropdownExpanded = false }
                    ) {
                        paymentPresets.forEach { preset ->
                            DropdownMenuItem(
                                text = { Text(preset) },
                                onClick = {
                                    paymentMethod = preset
                                    paymentDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Supported Coins
                OutlinedTextField(
                    value = supportedCoins,
                    onValueChange = { supportedCoins = it },
                    label = { Text("Supported Coins") },
                    placeholder = { Text("BTC, ETH, LTC, DOGE, SOL, USDT") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_input_coins")
                )

                // Minimum Withdrawal
                OutlinedTextField(
                    value = minimumWithdrawal,
                    onValueChange = { minimumWithdrawal = it },
                    label = { Text("Minimum Withdrawal") },
                    placeholder = { Text("e.g. $1.00 or 1,000 Coins") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_input_min_withdraw")
                )

                // Claim Timer default duration (minutes)
                OutlinedTextField(
                    value = timerDurationText,
                    onValueChange = { timerDurationText = it },
                    label = { Text("Timer Countdown (Minutes)") },
                    placeholder = { Text("60") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_input_timer")
                )

                // Star Rating (1 to 5)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Rating:",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row {
                        (1..5).forEach { starIndex ->
                            IconButton(
                                onClick = { rating = starIndex },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = if (starIndex <= rating) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = "$starIndex Stars",
                                    tint = if (starIndex <= rating) AmberPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Favorite Priority Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Star as Favorite",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Pin towards top of list",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = isFavorite,
                        onCheckedChange = { isFavorite = it },
                        modifier = Modifier.testTag("dialog_switch_favorite")
                    )
                }

                // Notes & Strategy
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes & Daily Strategy") },
                    placeholder = { Text("Daily loyalty bonuses, shortlink tips, referral codes, captcha quirks...") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_input_notes")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        nameError = true
                        return@Button
                    }
                    if (url.isBlank()) {
                        urlError = true
                        return@Button
                    }

                    val normalizedUrl = if (url.startsWith("http://") || url.startsWith("https://")) {
                        url.trim()
                    } else {
                        "https://${url.trim()}"
                    }

                    val parsedUsd = estimatedDailyUsdText.toDoubleOrNull() ?: 0.0
                    val parsedTimer = timerDurationText.toIntOrNull() ?: 60

                    val itemToSave = (initialFaucet ?: FaucetItem(
                        name = name.trim(),
                        url = normalizedUrl,
                        expectedDailyReward = expectedDailyReward.trim()
                    )).copy(
                        name = name.trim(),
                        url = normalizedUrl,
                        expectedDailyReward = expectedDailyReward.trim(),
                        estimatedDailyUsd = parsedUsd,
                        estimatedTimeMinutes = estimatedTimeMinutes.toInt(),
                        status = status,
                        claimInterval = claimInterval.trim(),
                        paymentMethod = paymentMethod.trim(),
                        supportedCoins = supportedCoins.trim(),
                        minimumWithdrawal = minimumWithdrawal.trim(),
                        notes = notes.trim(),
                        isFavorite = isFavorite,
                        rating = rating,
                        timerDurationMinutes = parsedTimer
                    )

                    onSave(itemToSave)
                },
                colors = ButtonDefaults.buttonColors(containerColor = AmberPrimary),
                modifier = Modifier.testTag("dialog_save_button")
            ) {
                Text(if (isEditing) "Save Changes" else "Add Faucet")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("dialog_cancel_button")
            ) {
                Text("Cancel")
            }
        }
    )
}
