package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Gold & Amber palette (Crypto & Faucet theme)
val AmberPrimary = Color(0xFFF59E0B)
val AmberPrimaryVariant = Color(0xFFD97706)
val AmberSecondary = Color(0xFF10B981) // Emerald Green (paying/success)
val AmberTertiary = Color(0xFF06B6D4) // Electric Cyan (tech / links)

// Dark Theme Colors
val DarkBackground = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkCardBorder = Color(0xFF374151)
val DarkOnBackground = Color(0xFFF3F4F6)
val DarkOnSurface = Color(0xFFE5E7EB)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightCardBorder = Color(0xFFE2E8F0)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF1E293B)

// Status colors
val StatusPaying = Color(0xFF10B981) // Emerald
val StatusActive = Color(0xFF06B6D4) // Cyan
val StatusTesting = Color(0xFFF59E0B) // Amber
val StatusDegraded = Color(0xFFF97316) // Orange
val StatusInactive = Color(0xFF6B7280) // Gray
val StatusScam = Color(0xFFEF4444) // Red
