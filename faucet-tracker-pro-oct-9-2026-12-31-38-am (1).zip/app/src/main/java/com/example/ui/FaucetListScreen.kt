package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.FilterListOff
import androidx.compose.material.icons.filled.InvertColors
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.FaucetItem
import com.example.ui.components.BackupRestoreDialog
import com.example.ui.components.EditFaucetDialog
import com.example.ui.components.FaucetCard
import com.example.ui.components.FaucetDetailsDialog
import com.example.ui.components.FaucetFilterBar
import com.example.ui.components.FaucetStatsHeader
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.AmberSecondary
import com.example.viewmodel.FaucetViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FaucetListScreen(
    viewModel: FaucetViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val listState = rememberLazyListState()

    // Dialog States
    var showAddDialog by remember { mutableStateOf(false) }
    var editingFaucet by remember { mutableStateOf<FaucetItem?>(null) }
    var viewingFaucet by remember { mutableStateOf<FaucetItem?>(null) }
    var showBackupDialog by remember { mutableStateOf(false) }

    // Snackbar notifications
    LaunchedEffect(uiState.userMessage) {
        uiState.userMessage?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.clearUserMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(AmberPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.WaterDrop,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Faucet Maintainer",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Daily Rewards & Task Routine",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showBackupDialog = true },
                        modifier = Modifier.testTag("backup_menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Backup and Presets"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = "Add Faucet") },
                text = { Text("Add Faucet", fontWeight = FontWeight.Bold) },
                containerColor = AmberPrimary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("fab_add_faucet")
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        if (uiState.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = AmberPrimary)
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .testTag("faucet_lazy_column"),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header item: Stats Summary & Daily Routine Progress
                item(key = "stats_header") {
                    FaucetStatsHeader(
                        stats = uiState.stats,
                        onResetToday = { viewModel.resetDailyRoutine() },
                        onMarkAllDoneToday = { viewModel.markAllDoneToday() }
                    )
                }

                // Filter & Search Bar
                item(key = "filter_bar") {
                    FaucetFilterBar(
                        filterState = uiState.filterState,
                        onQueryChange = { viewModel.updateSearchQuery(it) },
                        onStatusSelected = { viewModel.setStatusFilter(it) },
                        onSortSelected = { viewModel.setSortOption(it) },
                        onToggleFavorites = { viewModel.toggleFavoritesOnly() },
                        onTogglePending = { viewModel.togglePendingOnly() }
                    )
                }

                // Section title & count
                item(key = "list_header_title") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (uiState.filterState.statusFilter != null)
                                "${uiState.filterState.statusFilter?.displayName} Faucets (${uiState.filteredFaucets.size})"
                            else
                                "All Tracked Faucets (${uiState.filteredFaucets.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        if (uiState.filterState.searchQuery.isNotEmpty() ||
                            uiState.filterState.statusFilter != null ||
                            uiState.filterState.favoritesOnly ||
                            uiState.filterState.pendingOnly
                        ) {
                            Text(
                                text = "Filtered",
                                style = MaterialTheme.typography.labelSmall,
                                color = AmberPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // Empty state if no items match filter
                if (uiState.filteredFaucets.isEmpty()) {
                    item(key = "empty_state") {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp)
                                .testTag("empty_state_view"),
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = if (uiState.faucets.isEmpty()) Icons.Default.WaterDrop else Icons.Default.FilterListOff,
                                    contentDescription = null,
                                    modifier = Modifier.size(48.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = if (uiState.faucets.isEmpty())
                                        "No Faucets Tracked Yet"
                                    else
                                        "No Matching Faucets",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (uiState.faucets.isEmpty())
                                        "Start adding crypto faucets to track your expected daily rewards, task times, and claim schedules."
                                    else
                                        "Try adjusting your search query, status filters, or starred settings.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(16.dp))

                                if (uiState.faucets.isEmpty()) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { showAddDialog = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = AmberPrimary)
                                        ) {
                                            Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Add Faucet")
                                        }

                                        OutlinedButton(
                                            onClick = { viewModel.restorePresets() }
                                        ) {
                                            Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Load Presets")
                                        }
                                    }
                                } else {
                                    OutlinedButton(
                                        onClick = { viewModel.clearFilters() }
                                    ) {
                                        Text("Clear Filters")
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // List of faucet items
                    items(
                        items = uiState.filteredFaucets,
                        key = { it.id }
                    ) { faucet ->
                        FaucetCard(
                            faucet = faucet,
                            onToggleCompletion = { viewModel.toggleCompletion(faucet) },
                            onToggleFavorite = { viewModel.toggleFavorite(faucet) },
                            onEdit = { editingFaucet = faucet },
                            onDelete = { viewModel.deleteFaucet(faucet) },
                            onDuplicate = { viewModel.duplicateFaucet(faucet) },
                            onViewDetails = { viewingFaucet = faucet },
                            onStartTimer = { duration -> viewModel.startTimer(faucet, duration) },
                            onClearTimer = { viewModel.clearTimer(faucet) }
                        )
                    }
                }
            }
        }
    }

    // Add Faucet Dialog
    if (showAddDialog) {
        EditFaucetDialog(
            initialFaucet = null,
            onDismiss = { showAddDialog = false },
            onSave = { newFaucet ->
                viewModel.saveFaucet(newFaucet)
                showAddDialog = false
            }
        )
    }

    // Edit Faucet Dialog
    editingFaucet?.let { faucetToEdit ->
        EditFaucetDialog(
            initialFaucet = faucetToEdit,
            onDismiss = { editingFaucet = null },
            onSave = { updatedFaucet ->
                viewModel.saveFaucet(updatedFaucet)
                editingFaucet = null
            }
        )
    }

    // View Details Dialog
    viewingFaucet?.let { faucetToView ->
        FaucetDetailsDialog(
            faucet = faucetToView,
            onDismiss = { viewingFaucet = null },
            onEdit = {
                val item = viewingFaucet
                viewingFaucet = null
                editingFaucet = item
            },
            onToggleCompletion = { viewModel.toggleCompletion(faucetToView) },
            onStartTimer = { viewModel.startTimer(faucetToView) }
        )
    }

    // Backup & Restore Dialog
    if (showBackupDialog) {
        BackupRestoreDialog(
            onDismiss = { showBackupDialog = false },
            onExportJson = { viewModel.exportToJson() },
            onImportJson = { json -> viewModel.importFromJson(json) },
            onRestorePresets = { viewModel.restorePresets() },
            onClearAll = { viewModel.clearAllData() }
        )
    }
}
