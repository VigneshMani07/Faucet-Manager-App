package com.example.viewmodel

data class FaucetStats(
    val totalCount: Int = 0,
    val payingCount: Int = 0,
    val totalDailyUsd: Double = 0.0,
    val totalDailyMinutes: Int = 0,
    val completedCount: Int = 0,
    val completionPercentage: Float = 0f,
    val hourlyRateUsd: Double = 0.0
)
