package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.FaucetDatabase
import com.example.data.FaucetItem
import com.example.data.FaucetRepository
import com.example.data.FaucetStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class FaucetUiState(
    val faucets: List<FaucetItem> = emptyList(),
    val filteredFaucets: List<FaucetItem> = emptyList(),
    val filterState: FaucetFilterState = FaucetFilterState(),
    val stats: FaucetStats = FaucetStats(),
    val isLoading: Boolean = false,
    val userMessage: String? = null
)

class FaucetViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: FaucetRepository

    init {
        val database = FaucetDatabase.getDatabase(application, viewModelScope)
        repository = FaucetRepository(database.faucetDao())

        // Ensure database is populated if first run
        viewModelScope.launch {
            if (repository.getCount() == 0) {
                repository.restoreDefaultPresets()
            }
        }
    }

    private val _filterState = MutableStateFlow(FaucetFilterState())
    private val _userMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<FaucetUiState> = combine(
        repository.allFaucets,
        _filterState,
        _userMessage
    ) { allFaucets, filter, message ->
        val filtered = applyFilterAndSort(allFaucets, filter)
        val stats = calculateStats(allFaucets)
        FaucetUiState(
            faucets = allFaucets,
            filteredFaucets = filtered,
            filterState = filter,
            stats = stats,
            isLoading = false,
            userMessage = message
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = FaucetUiState(isLoading = true)
    )

    private fun applyFilterAndSort(
        list: List<FaucetItem>,
        filter: FaucetFilterState
    ): List<FaucetItem> {
        return list.filter { item ->
            // Search filter
            val query = filter.searchQuery.trim().lowercase()
            val matchesQuery = query.isEmpty() ||
                    item.name.lowercase().contains(query) ||
                    item.url.lowercase().contains(query) ||
                    item.supportedCoins.lowercase().contains(query) ||
                    item.paymentMethod.lowercase().contains(query) ||
                    item.notes.lowercase().contains(query)

            // Status filter
            val matchesStatus = filter.statusFilter == null || item.status == filter.statusFilter

            // Favorites filter
            val matchesFavorites = !filter.favoritesOnly || item.isFavorite

            // Pending today filter
            val matchesPending = !filter.pendingOnly || !item.isCompletedToday

            matchesQuery && matchesStatus && matchesFavorites && matchesPending
        }.sortedWith { a, b ->
            when (filter.sortOption) {
                SortOption.DEFAULT -> {
                    // Starred first, then by status priority, then name
                    val favCompare = b.isFavorite.compareTo(a.isFavorite)
                    if (favCompare != 0) favCompare
                    else a.name.compareTo(b.name, ignoreCase = true)
                }
                SortOption.REWARD_HIGH_TO_LOW -> b.estimatedDailyUsd.compareTo(a.estimatedDailyUsd)
                SortOption.TIME_LOW_TO_HIGH -> a.estimatedTimeMinutes.compareTo(b.estimatedTimeMinutes)
                SortOption.TIME_HIGH_TO_LOW -> b.estimatedTimeMinutes.compareTo(a.estimatedTimeMinutes)
                SortOption.NAME_A_TO_Z -> a.name.compareTo(b.name, ignoreCase = true)
                SortOption.RATING_HIGH_TO_LOW -> b.rating.compareTo(a.rating)
                SortOption.STATUS -> a.status.ordinal.compareTo(b.status.ordinal)
            }
        }
    }

    private fun calculateStats(faucets: List<FaucetItem>): FaucetStats {
        if (faucets.isEmpty()) return FaucetStats()

        val paying = faucets.filter { it.status == FaucetStatus.PAYING || it.status == FaucetStatus.ACTIVE }
        val totalDailyUsd = paying.sumOf { it.estimatedDailyUsd }
        val totalDailyMinutes = paying.sumOf { it.estimatedTimeMinutes }
        val completedCount = faucets.count { it.isCompletedToday }
        val completionPercentage = if (faucets.isNotEmpty()) {
            completedCount.toFloat() / faucets.size.toFloat()
        } else 0f

        val hourlyRate = if (totalDailyMinutes > 0) {
            totalDailyUsd / (totalDailyMinutes / 60.0)
        } else 0.0

        return FaucetStats(
            totalCount = faucets.size,
            payingCount = paying.size,
            totalDailyUsd = totalDailyUsd,
            totalDailyMinutes = totalDailyMinutes,
            completedCount = completedCount,
            completionPercentage = completionPercentage,
            hourlyRateUsd = hourlyRate
        )
    }

    fun updateSearchQuery(query: String) {
        _filterState.value = _filterState.value.copy(searchQuery = query)
    }

    fun setStatusFilter(status: FaucetStatus?) {
        _filterState.value = _filterState.value.copy(statusFilter = status)
    }

    fun setSortOption(sortOption: SortOption) {
        _filterState.value = _filterState.value.copy(sortOption = sortOption)
    }

    fun toggleFavoritesOnly() {
        _filterState.value = _filterState.value.copy(favoritesOnly = !_filterState.value.favoritesOnly)
    }

    fun togglePendingOnly() {
        _filterState.value = _filterState.value.copy(pendingOnly = !_filterState.value.pendingOnly)
    }

    fun clearFilters() {
        _filterState.value = FaucetFilterState()
    }

    fun saveFaucet(faucet: FaucetItem) {
        viewModelScope.launch {
            if (faucet.id == 0L) {
                repository.insertFaucet(faucet)
                showMessage("Added ${faucet.name}")
            } else {
                repository.updateFaucet(faucet)
                showMessage("Updated ${faucet.name}")
            }
        }
    }

    fun duplicateFaucet(faucet: FaucetItem) {
        viewModelScope.launch {
            val duplicate = faucet.copy(
                id = 0L,
                name = "${faucet.name} (Copy)",
                isCompletedToday = false,
                timerStartedAt = 0L,
                createdAt = System.currentTimeMillis()
            )
            repository.insertFaucet(duplicate)
            showMessage("Duplicated ${faucet.name}")
        }
    }

    fun deleteFaucet(faucet: FaucetItem) {
        viewModelScope.launch {
            repository.deleteFaucet(faucet)
            showMessage("Deleted ${faucet.name}")
        }
    }

    fun toggleCompletion(faucet: FaucetItem) {
        viewModelScope.launch {
            val newStatus = !faucet.isCompletedToday
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            repository.setCompletion(faucet.id, newStatus, if (newStatus) todayStr else "")
        }
    }

    fun toggleFavorite(faucet: FaucetItem) {
        viewModelScope.launch {
            repository.toggleFavorite(faucet.id, !faucet.isFavorite)
        }
    }

    fun resetDailyRoutine() {
        viewModelScope.launch {
            repository.resetAllDailyCompleted()
            showMessage("Daily task checklist reset for today")
        }
    }

    fun markAllDoneToday() {
        viewModelScope.launch {
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            repository.markAllDailyCompleted(todayStr)
            showMessage("All faucets marked completed for today!")
        }
    }

    fun startTimer(faucet: FaucetItem, durationMinutes: Int = faucet.timerDurationMinutes) {
        viewModelScope.launch {
            val duration = if (durationMinutes > 0) durationMinutes else 60
            repository.startTimer(faucet.id, duration)
            showMessage("Timer set for ${duration}m on ${faucet.name}")
        }
    }

    fun clearTimer(faucet: FaucetItem) {
        viewModelScope.launch {
            repository.clearTimer(faucet.id)
        }
    }

    fun restorePresets() {
        viewModelScope.launch {
            repository.restoreDefaultPresets()
            showMessage("Sample presets added to list")
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAll()
            showMessage("All faucets removed")
        }
    }

    fun exportToJson(): String {
        val currentList = uiState.value.faucets
        val array = JSONArray()
        for (item in currentList) {
            val obj = JSONObject().apply {
                put("name", item.name)
                put("url", item.url)
                put("expectedDailyReward", item.expectedDailyReward)
                put("estimatedDailyUsd", item.estimatedDailyUsd)
                put("estimatedTimeMinutes", item.estimatedTimeMinutes)
                put("status", item.status.name)
                put("claimInterval", item.claimInterval)
                put("paymentMethod", item.paymentMethod)
                put("supportedCoins", item.supportedCoins)
                put("minimumWithdrawal", item.minimumWithdrawal)
                put("notes", item.notes)
                put("isFavorite", item.isFavorite)
                put("rating", item.rating)
                put("timerDurationMinutes", item.timerDurationMinutes)
            }
            array.put(obj)
        }
        return array.toString(2)
    }

    fun importFromJson(jsonString: String): Result<Int> {
        return try {
            val array = JSONArray(jsonString)
            val list = mutableListOf<FaucetItem>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val item = FaucetItem(
                    name = obj.optString("name", "Unnamed Faucet"),
                    url = obj.optString("url", "https://"),
                    expectedDailyReward = obj.optString("expectedDailyReward", "$0.10"),
                    estimatedDailyUsd = obj.optDouble("estimatedDailyUsd", 0.10),
                    estimatedTimeMinutes = obj.optInt("estimatedTimeMinutes", 10),
                    status = FaucetStatus.fromString(obj.optString("status", "ACTIVE")),
                    claimInterval = obj.optString("claimInterval", "Hourly"),
                    paymentMethod = obj.optString("paymentMethod", "FaucetPay"),
                    supportedCoins = obj.optString("supportedCoins", "BTC"),
                    minimumWithdrawal = obj.optString("minimumWithdrawal", "Low"),
                    notes = obj.optString("notes", ""),
                    isFavorite = obj.optBoolean("isFavorite", false),
                    rating = obj.optInt("rating", 4),
                    timerDurationMinutes = obj.optInt("timerDurationMinutes", 60)
                )
                list.add(item)
            }
            viewModelScope.launch {
                repository.importFaucets(list)
                showMessage("Successfully imported ${list.size} faucets")
            }
            Result.success(list.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    private fun showMessage(msg: String) {
        _userMessage.value = msg
    }
}
