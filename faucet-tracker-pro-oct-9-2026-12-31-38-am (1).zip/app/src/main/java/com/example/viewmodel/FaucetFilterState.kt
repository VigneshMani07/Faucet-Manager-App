package com.example.viewmodel

import com.example.data.FaucetStatus

enum class SortOption(val label: String) {
    DEFAULT("Default (Priority)"),
    REWARD_HIGH_TO_LOW("Highest Daily Reward"),
    TIME_LOW_TO_HIGH("Quickest Task Time"),
    TIME_HIGH_TO_LOW("Longest Task Time"),
    NAME_A_TO_Z("Name (A to Z)"),
    RATING_HIGH_TO_LOW("Highest Rating"),
    STATUS("Status")
}

data class FaucetFilterState(
    val searchQuery: String = "",
    val statusFilter: FaucetStatus? = null,
    val sortOption: SortOption = SortOption.DEFAULT,
    val favoritesOnly: Boolean = false,
    val pendingOnly: Boolean = false,
    val selectedCoin: String? = null
)
